'use strict';

require('dotenv').config();

const path = require('path');
const http = require('http');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const session = require('express-session');

const { initDb } = require('./src/db');
const { initSocket } = require('./src/socket');
const { initWhatsApp } = require('./src/whatsapp');

// Route imports
const authRoutes = require('./src/routes/auth.routes');
const whatsappRoutes = require('./src/routes/whatsapp.routes');
const chatsRoutes = require('./src/routes/chats.routes');
const messagesRoutes = require('./src/routes/messages.routes');
const autoreplyRoutes = require('./src/routes/autoreply.routes');

// Middleware imports
const { requireAuth } = require('./src/middleware/auth.middleware');
const { globalLimiter } = require('./src/middleware/rateLimit');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '127.0.0.1';
const AUTH_ENABLED = String(process.env.AUTH_ENABLED || 'false').toLowerCase() === 'true';
const SESSION_SECRET =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16
    ? process.env.SESSION_SECRET
    : 'dev_only_secret_change_me_please_1234567890';

if (SESSION_SECRET.startsWith('dev_only')) {
  console.warn('[WARN] Using insecure default SESSION_SECRET. Set it in .env');
}

// --- Init DB first (synchronous, better-sqlite3) ---
initDb();

const app = express();
const server = http.createServer(app);

// --- Security & parsing ---
app.disable('x-powered-by');

app.use(
  helmet({
    contentSecurityPolicy: false, // We serve inline CSS in HTML; keep CSP off for local use
    crossOriginEmbedderPolicy: false
  })
);

app.use(
  cors({
    origin: (origin, cb) => {
      // Allow same-origin / no-origin (curl, same host) and localhost variants
      if (!origin) return cb(null, true);
      const allowed =
        origin.startsWith('http://127.0.0.1') ||
        origin.startsWith('http://localhost') ||
        origin.startsWith(`http://${HOST}`);
      return cb(allowed ? null : new Error('Not allowed by CORS'), allowed);
    },
    credentials: true
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

// Simple request log (no message content)
app.use(
  morgan(':method :url :status :res[content-length] - :response-time ms', {
    skip: (req) => req.path.startsWith('/socket.io')
  })
);

// --- Session (for optional auth mode) ---
app.use(
  session({
    name: 'wacm.sid',
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: false, // local http
      maxAge: 1000 * 60 * 60 * 12 // 12h
    }
  })
);

// --- Rate limit all API ---
app.use('/api', globalLimiter);

// --- Health (public) ---
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    service: 'whatsapp-chat-manager',
    authEnabled: AUTH_ENABLED,
    time: new Date().toISOString()
  });
});

// --- Auth routes (login/logout) ---
app.use('/api/auth', authRoutes);

// --- Protect everything else under /api ---
const protect = AUTH_ENABLED ? requireAuth : (req, res, next) => next();

app.use('/api/whatsapp', protect, whatsappRoutes);
app.use('/api/chats', protect, chatsRoutes);
app.use('/api/messages', protect, messagesRoutes);
app.use('/api/autoreply', protect, autoreplyRoutes);

// --- Static frontend ---
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

// --- Optional login page redirect (if auth enabled) ---
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// SPA fallback: only for non-api, non-socket
app.get(/^\/(?!api|socket\.io).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- 404 for unknown API ---
app.use('/api', (req, res) => {
  res.status(404).json({ ok: false, error: 'API endpoint not found' });
});

// --- Global error handler ---
app.use((err, req, res, next) => {
  console.error('[ERROR]', err && err.message ? err.message : err);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({
    ok: false,
    error: err.expose ? err.message : 'Internal server error'
  });
});

// --- Socket.IO ---
const io = initSocket(server);
app.set('io', io); // make available via req.app.get('io') if needed

// --- Start WhatsApp client (async, QR will be emitted via socket) ---
initWhatsApp(io).catch((e) => {
  console.error('[WA] Failed to init:', e && e.message ? e.message : e);
});

// --- Start server ---
server.listen(PORT, HOST, () => {
  console.log('');
  console.log('==================================================');
  console.log('  WhatsApp Chat Manager');
  console.log('==================================================');
  console.log(`  URL       : http://${HOST}:${PORT}`);
  console.log(`  Auth mode : ${AUTH_ENABLED ? 'ENABLED (login required)' : 'DISABLED (local only)'}`);
  console.log(`  Bind      : ${HOST} (do not expose publicly)`);
  console.log('==================================================');
  console.log('');
});

// --- Graceful shutdown ---
process.on('SIGINT', async () => {
  console.log('\n[SHUTDOWN] SIGINT received, closing...');
  try {
    const { getClient } = require('./src/whatsapp');
    const client = getClient();
    if (client) {
      await client.destroy();
      console.log('[SHUTDOWN] WhatsApp client destroyed');
    }
  } catch (e) {
    console.error('[SHUTDOWN] WA destroy error:', e && e.message);
  }
  io.close();
  server.close(() => {
    console.log('[SHUTDOWN] Server closed');
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 5000);
});

process.on('SIGTERM', () => {
  process.emit('SIGINT');
});

process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason && reason.message ? reason.message : reason);
});

process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]', err && err.message ? err.message : err);
});