'use strict';

/**
 * App bootstrap — toasts, module init, auth check.
 */
window.WACM = window.WACM || {};

(function () {
  const toastContainer = document.getElementById('toastContainer');

  function toast(message, type) {
    if (!toastContainer) return;
    const el = document.createElement('div');
    el.className = 'toast' + (type ? ' ' + type : '');
    el.textContent = message;
    toastContainer.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateX(20px)';
      el.style.transition = 'all .3s';
      setTimeout(() => el.remove(), 300);
    }, 3500);
  }

  window.WACM.toast = toast;

  // Close modals on backdrop click
  document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) backdrop.classList.remove('show');
    });
  });

  // Escape closes modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.show').forEach((m) => {
        m.classList.remove('show');
      });
    }
  });

  // ---------- Auth check ----------
  async function checkAuth() {
    try {
      const res = await fetch('/api/auth/me', { credentials: 'include' });
      if (res.status === 401) {
        window.location.href = '/login';
        return false;
      }
      const data = await res.json();
      return Boolean(data.authenticated);
    } catch (_) {
      // If network error, allow (local-only default)
      return true;
    }
  }

  // ---------- Boot ----------
  async function boot() {
    const authed = await checkAuth();
    if (!authed) return;

    // Connect socket
    window.WACM.socket?.connect();

    // Init modules
    window.WACM.qrUI?.init();
    window.WACM.chatUI?.init();
    window.WACM.settingsUI?.init();

    console.log('[APP] Ready');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();