'use strict';

/**
 * Socket.IO client wrapper.
 * Exposes window.WACM.socket + helper to register handlers.
 */
window.WACM = window.WACM || {};

(function () {
  let socket = null;
  const handlers = {};

  function connect() {
    if (typeof io === 'undefined') {
      console.error('[SOCKET] socket.io client not loaded');
      return null;
    }
    if (socket) return socket;

    socket = io({
      withCredentials: true,
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000
    });

    socket.on('connect', () => {
      console.log('[SOCKET] connected', socket.id);
    });
    socket.on('disconnect', (reason) => {
      console.warn('[SOCKET] disconnected:', reason);
    });
    socket.on('connect_error', (err) => {
      console.warn('[SOCKET] connect_error:', err.message);
    });

    // Re-dispatch any registered handlers
    Object.keys(handlers).forEach((evt) => {
      handlers[evt].forEach((fn) => socket.on(evt, fn));
    });

    return socket;
  }

  function on(event, fn) {
    handlers[event] = handlers[event] || [];
    handlers[event].push(fn);
    if (socket) socket.on(event, fn);
  }

  window.WACM.socket = {
    connect,
    on,
    get raw() {
      return socket;
    }
  };
})();