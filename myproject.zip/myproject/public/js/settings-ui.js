'use strict';

/**
 * Settings UI — auto-reply global settings + keyword rules CRUD.
 */
window.WACM = window.WACM || {};

(function () {
  const $ = (id) => document.getElementById(id);

  const settingsModal = $('settingsModal');
  const btnSettings = $('btnSettings');
  const btnLogout = $('btnLogout');

  // Global settings controls
  const tglEnabled = $('tglEnabled');
  const tglFallback = $('tglFallback');
  const fallbackReply = $('fallbackReply');
  const cooldownSeconds = $('cooldownSeconds');
  const dupWindowSeconds = $('dupWindowSeconds');
  const btnSaveGlobal = $('btnSaveGlobal');

  // Rules
  const rulesContainer = $('rulesContainer');
  const btnAddRule = $('btnAddRule');

  // Rule edit modal
  const ruleModal = $('ruleModal');
  const ruleModalTitle = $('ruleModalTitle');
  const ruleIdInput = $('ruleId');
  const ruleKeyword = $('ruleKeyword');
  const ruleMatchType = $('ruleMatchType');
  const ruleReply = $('ruleReply');
  const rulePriority = $('rulePriority');
  const ruleEnabled = $('ruleEnabled');
  const btnSaveRule = $('btnSaveRule');
  const btnDeleteRule = $('btnDeleteRule');

  // Disabled contacts
  const disabledContacts = $('disabledContacts');

  // Local state
  let globalState = {
    enabled: true,
    cooldownSeconds: 60,
    duplicateWindowSeconds: 30,
    fallbackEnabled: false,
    fallbackReply: ''
  };

  function escapeHtml(s) {
    if (typeof s !== 'string') return '';
    return s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function toast(msg, type) {
    window.WACM.toast?.(msg, type);
  }

  function setToggle(el, on) {
    el.classList.toggle('on', Boolean(on));
  }

  function getToggle(el) {
    return el.classList.contains('on');
  }

  // ---------- Loaders ----------
  async function loadGlobalSettings() {
    try {
      const res = await fetch('/api/autoreply/settings', { credentials: 'include' });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Load failed');
      globalState = data.settings;
      setToggle(tglEnabled, globalState.enabled);
      setToggle(tglFallback, globalState.fallbackEnabled);
      fallbackReply.value = globalState.fallbackReply || '';
      cooldownSeconds.value = globalState.cooldownSeconds ?? 60;
      dupWindowSeconds.value = globalState.duplicateWindowSeconds ?? 30;
    } catch (e) {
      toast('Failed to load settings: ' + e.message, 'error');
    }
  }

  async function loadRules() {
    try {
      rulesContainer.innerHTML = '<div class="loading"><div class="spinner"></div> Loading rules...</div>';
      const res = await fetch('/api/autoreply/rules', { credentials: 'include' });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Load failed');
      renderRules(data.rules || []);
    } catch (e) {
      rulesContainer.innerHTML =
        '<div class="rules-empty">Failed to load rules: ' + escapeHtml(e.message) + '</div>';
    }
  }

  function renderRules(rules) {
    if (!rules.length) {
      rulesContainer.innerHTML =
        '<div class="rules-empty">No rules yet. Click "+ Add Rule".</div>';
      return;
    }

    const table = document.createElement('table');
    table.className = 'rules-table';
    table.innerHTML = `
      <thead>
        <tr>
          <th>Keyword</th>
          <th>Match</th>
          <th>Reply</th>
          <th>Priority</th>
          <th>Status</th>
          <th></th>
        </tr>
      </thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody');

    for (const r of rules) {
      const tr = document.createElement('tr');

      tr.innerHTML = `
        <td><span class="kw">${escapeHtml(r.keyword)}</span></td>
        <td>${escapeHtml(r.match_type)}</td>
        <td class="reply-cell">${escapeHtml(r.reply)}</td>
        <td>${r.priority}</td>
        <td>${r.enabled ? '✅' : '⏸️'}</td>
        <td>
          <button class="icon-btn" data-edit="${r.id}" title="Edit">✏️</button>
          <button class="icon-btn" data-del="${r.id}" title="Delete">🗑️</button>
        </td>
      `;
      tbody.appendChild(tr);
    }

    rulesContainer.innerHTML = '';
    rulesContainer.appendChild(table);

    rulesContainer.querySelectorAll('[data-edit]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.edit, 10);
        const rule = rules.find((x) => x.id === id);
        if (rule) openRuleModal(rule);
      });
    });
    rulesContainer.querySelectorAll('[data-del]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.dataset.del, 10);
        deleteRule(id);
      });
    });
  }

  async function loadDisabledContacts() {
    try {
      const res = await fetch('/api/autoreply/contacts', { credentials: 'include' });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      const list = data.contacts || [];
      if (!list.length) {
        disabledContacts.innerHTML =
          '<div class="rules-empty">No contacts disabled.</div>';
        return;
      }
      disabledContacts.innerHTML = list
        .map(
          (c) => `
        <div class="toggle-row">
          <div>
            <div style="font-family:monospace; font-size:12px;">${escapeHtml(c.chat_id)}</div>
            <div class="text-muted" style="font-size:12px;">Auto-reply OFF</div>
          </div>
          <button class="btn btn-secondary" data-enable="${escapeHtml(c.chat_id)}">Enable</button>
        </div>
      `
        )
        .join('');

      disabledContacts.querySelectorAll('[data-enable]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const chatId = btn.dataset.enable;
          try {
            const r = await fetch(
              `/api/autoreply/contacts/${encodeURIComponent(chatId)}/enable`,
              { method: 'POST', credentials: 'include' }
            );
            const d = await r.json();
            if (d.ok) {
              toast('Auto-reply enabled for ' + chatId);
              loadDisabledContacts();
            }
          } catch (_) {
            toast('Failed', 'error');
          }
        });
      });
    } catch (e) {
      disabledContacts.innerHTML =
        '<div class="rules-empty">Failed to load: ' + escapeHtml(e.message) + '</div>';
    }
  }

  // ---------- Rule CRUD ----------
  function openRuleModal(rule) {
    if (rule) {
      ruleModalTitle.textContent = 'Edit Rule';
      ruleIdInput.value = rule.id;
      ruleKeyword.value = rule.keyword;
      ruleMatchType.value = rule.match_type;
      ruleReply.value = rule.reply;
      rulePriority.value = rule.priority;
      setToggle(ruleEnabled, Boolean(rule.enabled));
      btnDeleteRule.classList.remove('hidden');
    } else {
      ruleModalTitle.textContent = 'Add Rule';
      ruleIdInput.value = '';
      ruleKeyword.value = '';
      ruleMatchType.value = 'exact';
      ruleReply.value = '';
      rulePriority.value = 0;
      setToggle(ruleEnabled, true);
      btnDeleteRule.classList.add('hidden');
    }
    ruleModal.classList.add('show');
    setTimeout(() => ruleKeyword.focus(), 50);
  }

  function closeRuleModal() {
    ruleModal.classList.remove('show');
  }

  async function saveRule() {
    const id = ruleIdInput.value ? parseInt(ruleIdInput.value, 10) : null;
    const payload = {
      keyword: ruleKeyword.value.trim(),
      reply: ruleReply.value,
      match_type: ruleMatchType.value,
      enabled: getToggle(ruleEnabled),
      priority: parseInt(rulePriority.value || '0', 10)
    };

    if (!payload.keyword) return toast('Keyword is required', 'error');
    if (!payload.reply.trim()) return toast('Reply is required', 'error');

    btnSaveRule.disabled = true;
    try {
      const url = id ? `/api/autoreply/rules/${id}` : '/api/autoreply/rules';
      const method = id ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Save failed');
      toast(id ? 'Rule updated' : 'Rule added');
      closeRuleModal();
      loadRules();
    } catch (e) {
      toast(e.message || 'Save failed', 'error');
    } finally {
      btnSaveRule.disabled = false;
    }
  }

  async function deleteRule(id) {
    if (!confirm('Delete this rule?')) return;
    try {
      const res = await fetch(`/api/autoreply/rules/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Delete failed');
      toast('Rule deleted');
      closeRuleModal();
      loadRules();
    } catch (e) {
      toast(e.message || 'Delete failed', 'error');
    }
  }

  // ---------- Save global ----------
  async function saveGlobal() {
    btnSaveGlobal.disabled = true;
    try {
      const payload = {
        enabled: getToggle(tglEnabled),
        fallbackEnabled: getToggle(tglFallback),
        fallbackReply: fallbackReply.value,
        cooldownSeconds: parseInt(cooldownSeconds.value || '60', 10),
        duplicateWindowSeconds: parseInt(dupWindowSeconds.value || '30', 10)
      };
      const res = await fetch('/api/autoreply/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Save failed');
      toast('Settings saved');
    } catch (e) {
      toast(e.message || 'Save failed', 'error');
    } finally {
      btnSaveGlobal.disabled = false;
    }
  }

  // ---------- Logout WhatsApp ----------
  async function logoutWhatsApp() {
    if (!confirm('Logout WhatsApp? Session will be deleted and you will need to scan QR again.')) {
      return;
    }
    try {
      const res = await fetch('/api/whatsapp/logout', {
        method: 'POST',
        credentials: 'include'
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Logout failed');
      toast('Logged out. Scan QR to reconnect.');
      window.WACM.qrUI?.openModal?.();
    } catch (e) {
      toast(e.message || 'Logout failed', 'error');
    }
  }

  // ---------- Init ----------
  function init() {
    btnSettings.addEventListener('click', () => {
      settingsModal.classList.add('show');
      loadGlobalSettings();
      loadRules();
      loadDisabledContacts();
    });

    btnLogout.addEventListener('click', logoutWhatsApp);

    document.querySelectorAll('[data-close="settingsModal"]').forEach((el) => {
      el.addEventListener('click', () => settingsModal.classList.remove('show'));
    });

    tglEnabled.addEventListener('click', () => setToggle(tglEnabled, !getToggle(tglEnabled)));
    tglFallback.addEventListener('click', () => setToggle(tglFallback, !getToggle(tglFallback)));
    ruleEnabled.addEventListener('click', () => setToggle(ruleEnabled, !getToggle(ruleEnabled)));

    btnSaveGlobal.addEventListener('click', saveGlobal);
    btnAddRule.addEventListener('click', () => openRuleModal(null));
    btnSaveRule.addEventListener('click', saveRule);
    btnDeleteRule.addEventListener('click', () => {
      const id = parseInt(ruleIdInput.value, 10);
      if (id) deleteRule(id);
    });

    document.querySelectorAll('[data-close="ruleModal"]').forEach((el) => {
      el.addEventListener('click', closeRuleModal);
    });
  }

  window.WACM.settingsUI = { init };
})();