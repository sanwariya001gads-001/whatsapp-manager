'use strict';

/**
 * QR modal UI — shows QR, refresh, and connection state.
 */
window.WACM = window.WACM || {};

(function () {
  const $ = (id) => document.getElementById(id);

  const qrModal = $('qrModal');
  const qrBox = $('qrBox');
  const qrPlaceholder = $('qrPlaceholder');
  const qrStatusLine = $('qrStatusLine');
  const btnRefreshQr = $('btnRefreshQr');
  const btnConnect = $('btnConnect');
  const btnQr = $('btnQr');
  const statusDot = $('statusDot');

  let currentDataUrl = null;

  function openModal() {
    qrModal.classList.add('show');
    fetchQr();
  }

  function closeModal() {
    qrModal.classList.remove('show');
  }

  function setQrImage(dataUrl) {
    currentDataUrl = dataUrl;
    qrBox.innerHTML = '';
    const img = document.createElement('img');
    img.src = dataUrl;
    img.alt = 'WhatsApp QR';
    qrBox.appendChild(img);
  }

  function setPlaceholder(text) {
    currentDataUrl = null;
    qrBox.innerHTML = '';
    const div = document.createElement('div');
    div.className = 'qr-placeholder';
    div.textContent = text;
    qrBox.appendChild(div);
  }

  async function fetchQr() {
    try {
      const res = await fetch('/api/whatsapp/qr', { credentials: 'include' });
      const data = await res.json();

      if (data.ok && data.available && data.dataUrl) {
        setQrImage(data.dataUrl);
        qrStatusLine.textContent = 'QR ready. Scan with WhatsApp.';
      } else {
        const state = await fetchStatus();
        if (state.status === 'connected') {
          setPlaceholder('✅ Already connected');
          qrStatusLine.textContent = 'Your WhatsApp is connected.';
        } else if (state.status === 'reconnecting') {
          setPlaceholder('Reconnecting...');
          qrStatusLine.textContent = 'Please wait, generating new QR soon.';
        } else if (state.status === 'error') {
          setPlaceholder('Error');
          qrStatusLine.textContent = state.lastError || 'Something went wrong. Try Refresh.';
        } else {
          setPlaceholder('Waiting for QR...');
          qrStatusLine.textContent = 'QR will appear here shortly.';
        }
      }
    } catch (e) {
      setPlaceholder('Failed to load QR');
      qrStatusLine.textContent = e.message || 'Network error';
    }
  }

  async function fetchStatus() {
    try {
      const res = await fetch('/api/whatsapp/status', { credentials: 'include' });
      const data = await res.json();
      if (data.ok) return data.state;
    } catch (_) {}
    return { status: 'disconnected' };
  }

  async function refreshQr() {
    btnRefreshQr.disabled = true;
    btnRefreshQr.textContent = 'Refreshing...';
    try {
      await fetch('/api/whatsapp/refresh', {
        method: 'POST',
        credentials: 'include'
      });
      setTimeout(fetchQr, 1500);
      setTimeout(fetchQr, 4000);
    } catch (e) {
      window.WACM.toast?.(e.message || 'Refresh failed', 'error');
    } finally {
      setTimeout(() => {
        btnRefreshQr.disabled = false;
        btnRefreshQr.textContent = 'Refresh QR';
      }, 3000);
    }
  }

  function updateStatusDot(status, title) {
    if (!statusDot) return;
    statusDot.className = 'status-dot ' + status;
    statusDot.title = title || status;
  }

  // ---- Socket events ----
  function bindSocket() {
    window.WACM.socket.on('wa:qr', (payload) => {
      if (payload && payload.dataUrl) {
        setQrImage(payload.dataUrl);
        qrStatusLine.textContent = 'QR ready. Scan with WhatsApp.';
        if (!qrModal.classList.contains('show')) {
          // auto-open if not connected
          const st = document.getElementById('statusDot');
          if (st && !st.classList.contains('connected')) openModal();
        }
      }
    });

    window.WACM.socket.on('wa:state', (state) => {
      updateStatusDot(state.status, state.lastError || state.status);

      if (state.status === 'connected') {
        setPlaceholder('✅ Connected');
        qrStatusLine.textContent = 'Connected as ' + (state.me?.name || 'your account');
        setTimeout(closeModal, 1200);
        // refresh chat list
        window.WACM.chatUI?.reloadChats?.();
      } else if (state.status === 'waiting_qr') {
        if (qrModal.classList.contains('show')) fetchQr();
      } else if (state.status === 'reconnecting') {
        setPlaceholder('Reconnecting...');
        qrStatusLine.textContent = 'Please wait...';
      } else if (state.status === 'disconnected') {
        setPlaceholder('Disconnected');
        qrStatusLine.textContent = 'Click Refresh QR to reconnect.';
      }
    });
  }

  // ---- Bind ----
  function init() {
    btnConnect?.addEventListener('click', openModal);
    btnQr?.addEventListener('click', openModal);
    btnRefreshQr?.addEventListener('click', refreshQr);

    document.querySelectorAll('[data-close="qrModal"]').forEach((el) => {
      el.addEventListener('click', closeModal);
    });

    bindSocket();
    fetchStatus().then((s) => updateStatusDot(s.status, s.lastError || s.status));
  }

  window.WACM.qrUI = { init, openModal, closeModal, refreshQr, fetchQr, fetchStatus };
})();