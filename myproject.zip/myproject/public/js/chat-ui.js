'use strict';

/**
 * Chat UI — chat list, message rendering, sending messages.
 */
window.WACM = window.WACM || {};

(function () {
  const $ = (id) => document.getElementById(id);

  const chatListEl = $('chatList');
  const messagesEl = $('messages');
  const chatViewEl = $('chatView');
  const emptyStateEl = $('emptyState');
  const chatTitleEl = $('chatTitle');
  const chatSubEl = $('chatSub');
  const chatAvatarEl = $('chatAvatar');
  const msgInputEl = $('msgInput');
  const btnSend = $('btnSend');
  const btnBack = $('btnBack');
  const searchInput = $('searchInput');
  const btnChatAutoReply = $('btnChatAutoReply');

  let allChats = [];
  let activeChatId = null;
  let activeChatMeta = null;
  let searchTimer = null;
  let autoReplyDisabledForActive = false;

  // ---------- Helpers ----------
  function escapeHtml(s) {
    if (typeof s !== 'string') return '';
    return s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function initials(name, number) {
    const base = (name || number || '?').trim();
    if (!base) return '?';
    const parts = base.split(/\s+/).filter(Boolean);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }

  function formatTime(ts) {
    if (!ts) return '';
    const d = new Date(ts);
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    if (sameDay) {
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return d.toLocaleDateString([], { day: '2-digit', month: '2-digit' });
  }

  function ackSymbol(ack) {
    if (ack === 0) return '🕐';
    if (ack === 1) return '✓';
    if (ack === 2) return '✓✓';
    if (ack === 3) return '✓✓';
    return '';
  }

  function ackClass(ack) {
    return ack === 3 ? 'msg-ack read' : 'msg-ack';
  }

  function toast(msg, type) {
    window.WACM.toast?.(msg, type);
  }

  // ---------- Chat list ----------
  async function reloadChats() {
    try {
      chatListEl.innerHTML = '<div class="loading"><div class="spinner"></div> Loading chats...</div>';
      const res = await fetch('/api/chats?limit=200', { credentials: 'include' });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Failed to load chats');
      allChats = data.chats || [];
      renderChatList();
    } catch (e) {
      chatListEl.innerHTML =
        '<div class="rules-empty">Failed to load chats: ' + escapeHtml(e.message) + '</div>';
    }
  }

  function renderChatList() {
    if (!allChats.length) {
      chatListEl.innerHTML =
        '<div class="empty-state" style="padding:30px;"><p>No chats yet.<br>Chats will appear once WhatsApp is connected.</p></div>';
      return;
    }

    const q = (searchInput?.value || '').toLowerCase().trim();
    const filtered = q
      ? allChats.filter(
          (c) =>
            (c.name || '').toLowerCase().includes(q) ||
            (c.number || '').includes(q) ||
            (c.last_message || '').toLowerCase().includes(q)
        )
      : allChats;

    if (!filtered.length) {
      chatListEl.innerHTML =
        '<div class="rules-empty">No chats match "' + escapeHtml(q) + '".</div>';
      return;
    }

    const frag = document.createDocumentFragment();
    for (const c of filtered) {
      const el = document.createElement('div');
      el.className = 'chat-item' + (c.id === activeChatId ? ' active' : '');
      el.dataset.chatId = c.id;

      const displayName = c.name || c.number || c.id;
      const timeStr = formatTime(c.last_ts);
      const unread = c.unread > 0 ? `<span class="unread-badge">${c.unread}</span>` : '';

      el.innerHTML = `
        <div class="avatar">${escapeHtml(initials(c.name, c.number))}</div>
        <div class="chat-meta">
          <div class="row1">
            <div class="chat-name">${escapeHtml(displayName)}</div>
            <div class="chat-time">${escapeHtml(timeStr)}</div>
          </div>
          <div class="row2">
            <div class="chat-preview">${escapeHtml(c.last_message || '')}</div>
            ${unread}
          </div>
        </div>
      `;

      el.addEventListener('click', () => openChat(c.id));
      frag.appendChild(el);
    }
    chatListEl.innerHTML = '';
    chatListEl.appendChild(frag);
  }

  // ---------- Chat view ----------
  async function openChat(chatId) {
    activeChatId = chatId;
    document.body.classList.add('show-chat');
    emptyStateEl.classList.add('hidden');
    chatViewEl.classList.remove('hidden');
    btnBack.classList.remove('hidden');

    // Highlight in list
    document.querySelectorAll('.chat-item').forEach((el) => {
      el.classList.toggle('active', el.dataset.chatId === chatId);
    });

    messagesEl.innerHTML =
      '<div class="loading"><div class="spinner"></div> Loading messages...</div>';

    try {
      const res = await fetch(`/api/chats/${encodeURIComponent(chatId)}/messages?limit=200`, {
        credentials: 'include'
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Failed to load messages');

      activeChatMeta = data.chat;
      updateHeader(data.chat);
      renderMessages(data.messages || []);

      // Mark chat read
      fetch(`/api/chats/${encodeURIComponent(chatId)}/read`, {
        method: 'POST',
        credentials: 'include'
      }).catch(() => {});

      // Reset unread in memory
      const c = allChats.find((x) => x.id === chatId);
      if (c) { c.unread = 0; renderChatList(); }

      // Check contact auto-reply state
      checkContactAutoReply(chatId);
    } catch (e) {
      messagesEl.innerHTML =
        '<div class="rules-empty">Failed to load messages: ' + escapeHtml(e.message) + '</div>';
    }
  }

  async function checkContactAutoReply(chatId) {
    try {
      const res = await fetch('/api/autoreply/contacts', { credentials: 'include' });
      const data = await res.json();
      if (data.ok) {
        autoReplyDisabledForActive = (data.contacts || []).some(
          (c) => c.chat_id === chatId
        );
        updateAutoReplyBtn();
      }
    } catch (_) {}
  }

  function updateAutoReplyBtn() {
    if (!btnChatAutoReply) return;
    if (autoReplyDisabledForActive) {
      btnChatAutoReply.textContent = '🚫';
      btnChatAutoReply.title = 'Auto-reply is OFF for this contact (click to enable)';
    } else {
      btnChatAutoReply.textContent = '🤖';
      btnChatAutoReply.title = 'Auto-reply is ON for this contact (click to disable)';
    }
  }

  function updateHeader(chat) {
    if (!chat) return;
    const name = chat.name || chat.number || chat.id;
    chatTitleEl.textContent = name;
    chatSubEl.textContent = chat.number ? '+' + chat.number : (chat.is_group ? 'Group' : '');
    chatAvatarEl.textContent = initials(chat.name, chat.number);
  }

  function renderMessages(messages) {
    messagesEl.innerHTML = '';
    if (!messages.length) {
      messagesEl.innerHTML =
        '<div class="msg-system">No messages yet. Say hi!</div>';
      return;
    }
    for (const m of messages) appendMessageBubble(m);
    scrollToBottom();
  }

  function appendMessageBubble(m) {
    const row = document.createElement('div');
    row.className = 'msg-row' + (m.from_me ? ' me' : '');
    row.dataset.msgId = m.id;

    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';

    const body = document.createElement('div');
    body.className = 'msg-body';
    body.textContent = m.body || ''; // textContent = XSS-safe

    const meta = document.createElement('div');
    meta.className = 'msg-meta';

    const timeSpan = document.createElement('span');
    timeSpan.textContent = formatTime(m.ts);

    meta.appendChild(timeSpan);

    if (m.from_me) {
      const ackSpan = document.createElement('span');
      ackSpan.className = ackClass(m.ack);
      ackSpan.textContent = ackSymbol(m.ack);
      ackSpan.title = 'Message status';
      meta.appendChild(ackSpan);
    }

    bubble.appendChild(body);
    bubble.appendChild(meta);
    row.appendChild(bubble);
    messagesEl.appendChild(row);
  }

  function scrollToBottom() {
    requestAnimationFrame(() => {
      messagesEl.scrollTop = messagesEl.scrollHeight;
    });
  }

  // ---------- Send ----------
  async function sendMessage() {
    if (!activeChatId) return;
    const text = (msgInputEl.value || '').trim();
    if (!text) return;

    btnSend.disabled = true;
    msgInputEl.disabled = true;

    try {
      const res = await fetch('/api/messages/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ chatId: activeChatId, text })
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || 'Send failed');
      }

      msgInputEl.value = '';
      adjustInputHeight();

      // If socket didn't push yet, render immediately
      if (data.message && !document.querySelector(`[data-msg-id="${data.message.id}"]`)) {
        appendMessageBubble({
          id: data.message.id,
          chat_id: activeChatId,
          from_me: 1,
          body: text,
          type: 'chat',
          ack: data.message.ack || 0,
          ts: data.message.ts || Date.now()
        });
        scrollToBottom();
      }
    } catch (e) {
      toast(e.message || 'Failed to send', 'error');
    } finally {
      btnSend.disabled = false;
      msgInputEl.disabled = false;
      msgInputEl.focus();
    }
  }

  // ---------- Input handling ----------
  function adjustInputHeight() {
    msgInputEl.style.height = 'auto';
    msgInputEl.style.height = Math.min(msgInputEl.scrollHeight, 120) + 'px';
  }

  function onInputChanged() {
    const has = (msgInputEl.value || '').trim().length > 0;
    btnSend.disabled = !has || !activeChatId;
    adjustInputHeight();
  }

  // ---------- Socket handlers ----------
  function bindSocket() {
    window.WACM.socket.on('message:new', (m) => {
      // Update sidebar preview
      const c = allChats.find((x) => x.id === m.chatId);
      if (c) {
        c.last_message =
          m.type === 'chat' ? (m.body || '').slice(0, 120) : `[${m.type}]`;
        c.last_ts = m.ts || Date.now();
        if (!m.fromMe && activeChatId !== m.chatId) {
          c.unread = (c.unread || 0) + 1;
        }
        allChats.sort((a, b) => (b.last_ts || 0) - (a.last_ts || 0));
        renderChatList();
      } else {
        // New chat, refresh list
        reloadChats();
      }

      // Append to open chat
      if (activeChatId === m.chatId) {
        if (document.querySelector(`[data-msg-id="${m.id}"]`)) {
          // Already exists — just update ack if present
          return;
        }
        appendMessageBubble({
          id: m.id,
          chat_id: m.chatId,
          from_me: m.fromMe ? 1 : 0,
          body: m.body || '',
          type: m.type || 'chat',
          ack: m.ack || 0,
          ts: m.ts || Date.now()
        });
        scrollToBottom();

        if (!m.fromMe) {
          fetch(`/api/chats/${encodeURIComponent(m.chatId)}/read`, {
            method: 'POST',
            credentials: 'include'
          }).catch(() => {});
        }
      }
    });

    window.WACM.socket.on('message:ack', (p) => {
      const el = document.querySelector(`[data-msg-id="${p.id}"] .msg-ack`);
      if (el) {
        el.className = ackClass(p.ack);
        el.textContent = ackSymbol(p.ack);
      }
    });

    window.WACM.socket.on('chat:update', () => {
      // Light refresh
      if (!activeChatId) reloadChats();
      else {
        // update preview only via message:new; no full reload needed
      }
    });
  }

  // ---------- Init ----------
  function init() {
    btnSend.addEventListener('click', sendMessage);
    msgInputEl.addEventListener('input', onInputChanged);
    msgInputEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });

    btnBack.addEventListener('click', () => {
      document.body.classList.remove('show-chat');
      activeChatId = null;
      chatViewEl.classList.add('hidden');
      emptyStateEl.classList.remove('hidden');
      document.querySelectorAll('.chat-item').forEach((el) => el.classList.remove('active'));
    });

    searchInput.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(renderChatList, 200);
    });

    btnChatAutoReply.addEventListener('click', async () => {
      if (!activeChatId) return;
      const endpoint = autoReplyDisabledForActive ? 'enable' : 'disable';
      try {
        const res = await fetch(
          `/api/autoreply/contacts/${encodeURIComponent(activeChatId)}/${endpoint}`,
          { method: 'POST', credentials: 'include' }
        );
        const data = await res.json();
        if (data.ok) {
          autoReplyDisabledForActive = !autoReplyDisabledForActive;
          updateAutoReplyBtn();
          toast(
            autoReplyDisabledForActive
              ? 'Auto-reply disabled for this contact'
              : 'Auto-reply enabled for this contact'
          );
        }
      } catch (_) {
        toast('Failed to update contact setting', 'error');
      }
    });

    bindSocket();
    reloadChats();
  }

  window.WACM.chatUI = { init, reloadChats, openChat };
})();