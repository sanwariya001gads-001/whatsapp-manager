# WhatsApp Chat Manager

Personal WhatsApp Web-style chat manager with auto-reply, built with **Node.js + Express + whatsapp-web.js + Socket.IO + SQLite**.

> ⚠️ **Important:** `whatsapp-web.js` is an **unofficial** WhatsApp Web automation library.
> - Can break when WhatsApp changes
> - May expose your account to restrictions / bans
> - Do **not** use for bulk messaging or spam
> - Use at your own risk, personal use only
> - This project does **not** bypass WhatsApp authentication — it uses the official QR scan flow

---

## Features

- 📷 QR code scan to connect your WhatsApp account (session persisted via LocalAuth)
- 💬 WhatsApp-style chat dashboard (recent chats, history, bubbles, timestamps, delivery status)
- ⚡ Real-time updates via Socket.IO
- 🤖 Auto-reply system:
  - Keyword rules (hi/hello/hey, 1, 2, 3, fallback)
  - Enable/disable globally
  - Per-contact disable
  - Cooldown + duplicate protection
  - Loop prevention
- 🔒 Local-only by default (binds to `127.0.0.1`)
- 🔑 Optional login for network access
- 💾 SQLite persistence for chats, messages, rules

---

## Requirements

- **Windows 10/11** (works on macOS/Linux too)
- **Node.js 18+** (LTS recommended) — https://nodejs.org
- **npm 9+** (comes with Node)
- A phone with WhatsApp installed

---

## Windows Installation

### 1. Install Node.js

1. Download Node.js LTS from https://nodejs.org
2. Run the installer, accept defaults
3. Verify in **CMD** (Win+R → type `cmd` → Enter):

```cmd
node -v
npm -v