'use strict';

const path = require('path');
const fs = require('fs');
const { Client, LocalAuth } = require('whatsapp-web.js');
const QRCode = require('qrcode');

const { getDb, getSetting, setSetting } = require('./db');

/** Singleton client + state */
let client = null;
let ioRef = null;

/**
 * Connection state machine:
 *   disconnected | waiting_qr | connected | reconnecting | error
 */
let state = {
  status: 'disconnected',
  qrDataUrl: null,
  lastError: null,
  me: null, // { id, name, number }
  updatedAt: Date.now()
};

function getState() {
  return { ...state };
}

function setState(patch) {
  state = { ...state, ...patch, updatedAt: Date.now() };
  if (ioRef) {
    ioRef.emit('wa:state', getPublicState());
  }
}

function getPublicState() {
  // Never expose raw QR in public state — fetch via /api/whatsapp/qr
  return {
    status: state.status,
    lastError: state.lastError,
    me: state.me,
    updatedAt: state.updatedAt
  };
}

function getClient() {
  return client;
}

function getIo() {
  return ioRef;
}

/**
 * Ensure required WhatsApp data folder exists (outside public).
 */
function ensureSessionDir() {
  const sessionPath = process.env.WA_SESSION_PATH || './data/.wwebjs_auth';
  const abs = path.isAbsolute(sessionPath)
    ? sessionPath
    : path.join(__dirname, '..', sessionPath.replace(/^\.\//, ''));
  const parent = path.dirname(abs);
  if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
  return abs;
}

/**
 * Upsert chat row into DB (from WA chat object).
 */
function upsertChat(chat) {
  if (!chat || !chat.id || !chat.id._serialized) return null;
  const db = getDb();
  const id = chat.id._serialized;
  const isGroup = Boolean(chat.isGroup);
  const name = chat.name || null;
  const number = !isGroup && chat.id.user ? chat.id.user : null;
  const ts = (chat.timestamp ? chat.timestamp * 1000 : Date.now()) | 0;

  const existing = db.prepare('SELECT id FROM chats WHERE id = ?').get(id);
  if (existing) {
    db.prepare(
      `UPDATE chats SET name = ?, number = ?, is_group = ?, updated_at = ?
       WHERE id = ?`
    ).run(name, number, isGroup ? 1 : 0, Date.now(), id);
  } else {
    db.prepare(
      `INSERT INTO chats (id, name, number, last_message, last_ts, unread, is_group, updated_at)
       VALUES (?, ?, ?, NULL, ?, 0, ?, ?)`
    ).run(id, name, number, ts, isGroup ? 1 : 0, Date.now());
  }
  return id;
}

/**
 * Store incoming/outgoing message into DB.
 */
function storeMessage(msg, chatId, fromMe) {
  try {
    const db = getDb();
    const id = msg.id && msg.id._serialized ? msg.id._serialized : `local_${Date.now()}`;
    const ts = (msg.timestamp ? msg.timestamp * 1000 : Date.now()) | 0;
    const type = msg.type || 'chat';
    const body = typeof msg.body === 'string' ? msg.body : '';

    const existing = db.prepare('SELECT id FROM messages WHERE id = ?').get(id);
    if (!existing) {
      db.prepare(
        `INSERT INTO messages (id, chat_id, from_me, author, body, type, media_path, ack, ts)
         VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?)`
      ).run(id, chatId, fromMe ? 1 : 0, msg.author || null, body, type, msg.ack || 0, ts);
    } else {
      // Update ack if changed
      db.prepare('UPDATE messages SET ack = ? WHERE id = ?').run(msg.ack || 0, id);
    }

    // Update chat last message preview
    const preview =
      type === 'chat'
        ? body.slice(0, 120)
        : `[${type}]`;
    db.prepare(
      `UPDATE chats SET last_message = ?, last_ts = ?, updated_at = ?
       WHERE id = ?`
    ).run(preview, ts, Date.now(), chatId);

    return id;
  } catch (e) {
    console.error('[WA] storeMessage error:', e.message);
    return null;
  }
}

/**
 * Initialize the WhatsApp client. Emits QR + state via Socket.IO.
 */
async function initWhatsApp(io) {
  ioRef = io || ioRef;

  if (client) {
    console.log('[WA] Client already exists, skipping re-init');
    return client;
  }

  const sessionAbs = ensureSessionDir();
  console.log('[WA] Session path:', sessionAbs);

  setState({ status: 'reconnecting', lastError: null });

  client = new Client({
    authStrategy: new LocalAuth({
      dataPath: sessionAbs
    }),
    puppeteer: {
      headless: process.env.WA_HEADLESS !== 'false',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu'
      ]
    },
    webVersionCache: {
      type: 'remote',
      remotePath:
        'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.2412.54.html'
    }
  });

  // --- QR event ---
  client.on('qr', async (qr) => {
    console.log('[WA] QR received');
    try {
      const dataUrl = await QRCode.toDataURL(qr, {
        errorCorrectionLevel: 'M',
        margin: 1,
        width: 320
      });
      setState({
        status: 'waiting_qr',
        qrDataUrl: dataUrl,
        lastError: null
      });
      if (ioRef) {
        ioRef.emit('wa:qr', { dataUrl, ts: Date.now() });
      }
    } catch (e) {
      console.error('[WA] QR generation failed:', e.message);
      setState({ status: 'error', lastError: 'QR generation failed' });
    }
  });

  // --- Loading / auth progress ---
  client.on('loading_screen', (percent, message) => {
    // Don't spam logs, but update status
    if (percent === 0 || percent === 100) {
      console.log(`[WA] Loading ${percent}% ${message || ''}`);
    }
  });

  // --- Authenticated (scan done, session saved) ---
  client.on('authenticated', () => {
    console.log('[WA] Authenticated — session saved');
    setState({ status: 'reconnecting', qrDataUrl: null });
  });

  client.on('auth_failure', (msg) => {
    console.error('[WA] Auth failure:', msg);
    setState({
      status: 'error',
      lastError: 'Authentication failed. Logout and scan again.',
      qrDataUrl: null
    });
  });

  // --- Ready ---
  client.on('ready', async () => {
    console.log('[WA] Client is READY');
    let me = null;
    try {
      const info = client.info;
      if (info) {
        me = {
          id: info.wid ? info.wid._serialized : null,
          name: info.pushname || null,
          number: info.wid ? info.wid.user : null
        };
      }
    } catch (e) {
      console.error('[WA] get info error:', e.message);
    }
    setState({
      status: 'connected',
      qrDataUrl: null,
      lastError: null,
      me
    });

    // Initial chat sync (last 30 chats) in background
    syncRecentChats().catch((e) =>
      console.error('[WA] initial sync error:', e.message)
    );
  });

  // --- Disconnected ---
  client.on('disconnected', (reason) => {
    console.warn('[WA] Disconnected:', reason);
    setState({
      status: 'disconnected',
      qrDataUrl: null,
      lastError: `Disconnected: ${reason || 'unknown'}`,
      me: null
    });
  });

  // --- Incoming message ---
  client.on('message', async (msg) => {
    try {
      if (!msg || !msg.from || !msg.id) return;

      const chatId = msg.from;
      const fromMe = Boolean(msg.fromMe);

      // Get chat meta
      let chat = null;
      try {
        chat = await msg.getChat();
      } catch (_) {}

      if (chat) upsertChat(chat);

      const msgId = storeMessage(msg, chatId, fromMe);

      // Emit real-time
      if (ioRef) {
        ioRef.emit('message:new', {
          id: msgId,
          chatId,
          fromMe,
          body: msg.body || '',
          type: msg.type || 'chat',
          ack: msg.ack || 0,
          ts: (msg.timestamp ? msg.timestamp * 1000 : Date.now()) | 0,
          chatName: chat ? chat.name : null
        });
        ioRef.emit('chat:update', { chatId });
      }

      // ---- Auto-reply pipeline (only incoming, not from me) ----
      if (!fromMe) {
        const { handleAutoReply } = require('./services/autoReply.service');
        // Fire and forget; errors caught inside
        handleAutoReply(msg, client).catch((e) =>
          console.error('[AUTOREPLY] handler error:', e.message)
        );
      }
    } catch (e) {
      console.error('[WA] message handler error:', e.message);
    }
  });

  // --- Message ack updates ---
  client.on('message_ack', (msg, ack) => {
    try {
      if (!msg || !msg.id || !msg.id._serialized) return;
      const db = getDb();
      db.prepare('UPDATE messages SET ack = ? WHERE id = ?').run(
        ack,
        msg.id._serialized
      );
      if (ioRef) {
        ioRef.emit('message:ack', {
          id: msg.id._serialized,
          ack,
          chatId: msg.from || (msg.to || null)
        });
      }
    } catch (e) {
      // ignore
    }
  });

  // --- Message create (also covers my outgoing from phone) ---
  client.on('message_create', async (msg) => {
    try {
      // Already handled in 'message' for incoming; here we handle outgoing
      // from our own phone (fromMe = true) so it shows in the dashboard.
      if (!msg || !msg.fromMe) return;
      if (!msg.id || !msg.id._serialized) return;

      const db = getDb();
      const exists = db
        .prepare('SELECT id FROM messages WHERE id = ?')
        .get(msg.id._serialized);
      if (exists) return; // already stored via send API

      const chatId = msg.to;
      if (!chatId) return;

      let chat = null;
      try {
        chat = await msg.getChat();
      } catch (_) {}
      if (chat) upsertChat(chat);

      const msgId = storeMessage(msg, chatId, true);
      if (ioRef) {
        ioRef.emit('message:new', {
          id: msgId,
          chatId,
          fromMe: true,
          body: msg.body || '',
          type: msg.type || 'chat',
          ack: msg.ack || 0,
          ts: (msg.timestamp ? msg.timestamp * 1000 : Date.now()) | 0,
          chatName: chat ? chat.name : null
        });
        ioRef.emit('chat:update', { chatId });
      }
    } catch (e) {
      // ignore
    }
  });

  // --- Initialize ---
  try {
    await client.initialize();
  } catch (e) {
    console.error('[WA] initialize error:', e.message);
    setState({
      status: 'error',
      lastError: e.message || 'Failed to initialize WhatsApp client'
    });
  }

  return client;
}

/**
 * Sync last N chats from WhatsApp into DB.
 */
async function syncRecentChats(limit = 30) {
  if (!client) return;
  try {
    const chats = await client.getChats();
    const sorted = chats
      .filter((c) => c && c.id && c.id._serialized)
      .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))
      .slice(0, limit);

    for (const chat of sorted) {
      upsertChat(chat);
    }
    if (ioRef) ioRef.emit('chat:update', { bulk: true });
  } catch (e) {
    console.error('[WA] syncRecentChats error:', e.message);
  }
}

/**
 * Send a text message and store it.
 */
async function sendText(chatId, text) {
  if (!client) throw Object.assign(new Error('WhatsApp not connected'), { status: 503 });
  if (!chatId || typeof chatId !== 'string') {
    throw Object.assign(new Error('Invalid chatId'), { status: 400, expose: true });
  }
  if (!text || typeof text !== 'string' || !text.trim()) {
    throw Object.assign(new Error('Empty message'), { status: 400, expose: true });
  }
  if (text.length > 4096) {
    throw Object.assign(new Error('Message too long (max 4096)'), {
      status: 400,
      expose: true
    });
  }

  const sent = await client.sendMessage(chatId, text);

  // Ensure chat exists
  const db = getDb();
  const chatRow = db.prepare('SELECT id, name FROM chats WHERE id = ?').get(chatId);
  if (!chatRow) {
    db.prepare(
      `INSERT INTO chats (id, name, number, last_message, last_ts, unread, is_group, updated_at)
       VALUES (?, ?, ?, ?, ?, 0, 0, ?)`
    ).run(
      chatId,
      chatId.replace('@c.us', ''),
      chatId.replace('@c.us', ''),
      text.slice(0, 120),
      Date.now(),
      Date.now()
    );
  }

  const msgId = storeMessage(sent, chatId, true);

  if (ioRef) {
    ioRef.emit('message:new', {
      id: msgId,
      chatId,
      fromMe: true,
      body: text,
      type: 'chat',
      ack: sent && sent.ack ? sent.ack : 0,
      ts: Date.now(),
      chatName: chatRow ? chatRow.name : null
    });
    ioRef.emit('chat:update', { chatId });
  }

  return {
    id: msgId,
    chatId,
    ack: sent && sent.ack ? sent.ack : 0,
    ts: Date.now()
  };
}

/**
 * Logout: destroy client + delete session folder.
 */
async function logout() {
  try {
    if (client) {
      try {
        await client.logout();
      } catch (_) {}
      try {
        await client.destroy();
      } catch (_) {}
      client = null;
    }
  } catch (e) {
    console.error('[WA] logout error:', e.message);
  }

  // Remove session folder
  try {
    const sessionPath = process.env.WA_SESSION_PATH || './data/.wwebjs_auth';
    const abs = path.isAbsolute(sessionPath)
      ? sessionPath
      : path.join(__dirname, '..', sessionPath.replace(/^\.\//, ''));
    if (fs.existsSync(abs)) {
      fs.rmSync(abs, { recursive: true, force: true });
      console.log('[WA] Session folder removed');
    }
  } catch (e) {
    console.error('[WA] session remove error:', e.message);
  }

  setState({
    status: 'disconnected',
    qrDataUrl: null,
    lastError: null,
    me: null
  });

  return true;
}

/**
 * Force reconnect: destroy + re-init.
 */
async function reconnect() {
  if (client) {
    try {
      await client.destroy();
    } catch (_) {}
    client = null;
  }
  setState({ status: 'reconnecting', qrDataUrl: null, lastError: null });
  return initWhatsApp(ioRef);
}

/**
 * Refresh QR: asks client to re-emit (may not work on all versions).
 * Fallback: full reconnect.
 */
async function refreshQr() {
  if (!client) {
    return initWhatsApp(ioRef);
  }
  setState({ status: 'waiting_qr', qrDataUrl: null, lastError: null });
  // Emit a signal; QR event will fire again on reconnect
  try {
    await client.destroy();
  } catch (_) {}
  client = null;
  return initWhatsApp(ioRef);
}

module.exports = {
  initWhatsApp,
  getClient,
  getState,
  getPublicState,
  sendText,
  logout,
  reconnect,
  refreshQr,
  syncRecentChats,
  upsertChat,
  storeMessage
};