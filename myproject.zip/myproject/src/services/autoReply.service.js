'use strict';

const crypto = require('crypto');
const { getDb, getSetting } = require('../db');

/**
 * Auto-Reply Service
 * ---------------------------------------------------------------------------
 * Responsibilities:
 *  - Match incoming message text against keyword rules
 *  - Respect per-contact disable flags
 *  - Enforce per-contact cooldown (no spammy replies)
 *  - Enforce duplicate protection (same reply not sent to same chat within N sec)
 *  - Never reply to our own messages
 *  - Prevent infinite loops (don't reply to auto-reply messages)
 *  - Optional fallback reply for unknown messages
 * ---------------------------------------------------------------------------
 */

// In-memory last-reply map: chatId -> timestamp (fast path)
const lastReplyAt = new Map(); // chatId -> ms

/**
 * Hash a reply string (short) to detect duplicates.
 */
function hashReply(text) {
  return crypto.createHash('sha1').update(text).digest('hex').slice(0, 16);
}

/**
 * Normalize text for matching.
 */
function normalize(text) {
  if (typeof text !== 'string') return '';
  return text.trim().toLowerCase();
}

/**
 * Match a single rule against normalized text.
 */
function matchRule(rule, textLower) {
  if (!rule || !rule.enabled) return false;
  const kw = normalize(rule.keyword);
  if (!kw) return false;

  switch (rule.match_type) {
    case 'exact':
      return textLower === kw;
    case 'starts':
      return textLower.startsWith(kw);
    case 'contains':
    default:
      return textLower.includes(kw);
  }
}

/**
 * Check per-contact disable flag.
 */
function isContactDisabled(chatId) {
  const db = getDb();
  const row = db
    .prepare('SELECT disabled FROM autoreply_contacts WHERE chat_id = ?')
    .get(chatId);
  return Boolean(row && row.disabled);
}

/**
 * Check cooldown (per contact).
 */
function inCooldown(chatId, cooldownSeconds) {
  if (!cooldownSeconds || cooldownSeconds <= 0) return false;

  const db = getDb();
  // Check DB log first (survives restart)
  const cutoff = Date.now() - cooldownSeconds * 1000;
  const recent = db
    .prepare(
      `SELECT ts FROM autoreply_log
       WHERE chat_id = ? AND ts > ?
       ORDER BY ts DESC LIMIT 1`
    )
    .get(chatId, cutoff);
  if (recent) return true;

  // Fast in-memory check
  const mem = lastReplyAt.get(chatId);
  if (mem && Date.now() - mem < cooldownSeconds * 1000) return true;

  return false;
}

/**
 * Check duplicate protection (same reply within N sec).
 */
function isDuplicate(chatId, replyText, windowSeconds) {
  if (!windowSeconds || windowSeconds <= 0) return false;
  const db = getDb();
  const cutoff = Date.now() - windowSeconds * 1000;
  const hash = hashReply(replyText);
  const row = db
    .prepare(
      `SELECT id FROM autoreply_log
       WHERE chat_id = ? AND reply_hash = ? AND ts > ?
       LIMIT 1`
    )
    .get(chatId, hash, cutoff);
  return Boolean(row);
}

/**
 * Log an auto-reply (for cooldown + duplicate tracking).
 */
function logReply(chatId, keyword, ruleId, replyText) {
  const db = getDb();
  const now = Date.now();
  db.prepare(
    `INSERT INTO autoreply_log (chat_id, keyword, rule_id, reply_hash, ts)
     VALUES (?, ?, ?, ?, ?)`
  ).run(chatId, keyword || null, ruleId || null, hashReply(replyText), now);
  lastReplyAt.set(chatId, now);

  // Trim old log rows (> 1 day old) occasionally
  if (Math.random() < 0.05) {
    try {
      db.prepare('DELETE FROM autoreply_log WHERE ts < ?').run(now - 86400000);
    } catch (_) {}
  }
}

/**
 * Check if a message body looks like one of our own auto-replies
 * (prevents infinite loops if user echoes back).
 */
function isLikelyOurAutoReply(text, rules) {
  const t = normalize(text);
  if (!t) return false;
  for (const r of rules) {
    if (!r.reply) continue;
    if (normalize(r.reply) === t) return true;
  }
  return false;
}

/**
 * Main entry: handle an incoming WhatsApp message and reply if a rule matches.
 *
 * @param {object} msg - whatsapp-web.js Message object
 * @param {object} client - whatsapp-web.js Client
 */
async function handleAutoReply(msg, client) {
  try {
    // ---- Guard: only incoming ----
    if (!msg || msg.fromMe) return;
    if (!msg.from) return;

    const chatId = msg.from;

    // ---- Guard: group chats ----
    // By default we DO NOT auto-reply to groups (safer). Toggle later if needed.
    const isGroup = chatId.endsWith('@g.us');
    if (isGroup) {
      return; // skip groups
    }

    // ---- Guard: body must be text ----
    const body = typeof msg.body === 'string' ? msg.body : '';
    if (!body || !body.trim()) return;

    // ---- Global ON/OFF ----
    const enabled = getSetting('autoreply_enabled', 'true') === 'true';
    if (!enabled) return;

    // ---- Per-contact disabled ----
    if (isContactDisabled(chatId)) return;

    // ---- Load settings ----
    const cooldownSec = parseInt(
      getSetting('autoreply_cooldown_seconds', '60'),
      10
    );
    const dupWinSec = parseInt(
      getSetting('autoreply_duplicate_window_seconds', '30'),
      10
    );
    const fallbackEnabled = getSetting('fallback_enabled', 'false') === 'true';
    const fallbackReply = getSetting('fallback_reply', '') || '';

    // ---- Cooldown ----
    if (inCooldown(chatId, cooldownSec)) {
      return;
    }

    // ---- Load rules ----
    const db = getDb();
    const rules = db
      .prepare(
        `SELECT id, keyword, reply, match_type, enabled, priority
         FROM autoreply_rules
         WHERE enabled = 1
         ORDER BY priority ASC, id ASC`
      )
      .all();

    if (!rules.length && !fallbackEnabled) return;

    // ---- Loop guard: if message is identical to one of our replies, skip ----
    if (isLikelyOurAutoReply(body, rules)) {
      return;
    }

    const textLower = normalize(body);

    // ---- Find first matching rule ----
    let matched = null;
    for (const rule of rules) {
      if (matchRule(rule, textLower)) {
        matched = rule;
        break;
      }
    }

    let replyText = null;
    let keyword = null;
    let ruleId = null;

    if (matched) {
      replyText = matched.reply;
      keyword = matched.keyword;
      ruleId = matched.id;
    } else if (fallbackEnabled && fallbackReply.trim()) {
      replyText = fallbackReply;
      keyword = '__fallback__';
      ruleId = null;
    }

    if (!replyText || !replyText.trim()) return;

    // ---- Duplicate protection ----
    if (isDuplicate(chatId, replyText, dupWinSec)) {
      return;
    }

    // ---- Send reply ----
    try {
      const sent = await client.sendMessage(chatId, replyText);
      // Mark log
      logReply(chatId, keyword, ruleId, replyText);

      // Emit socket event so dashboard updates live
      try {
        const { getIo } = require('../socket');
        const io = getIo();
        if (io) {
          const { storeMessage } = require('../whatsapp');
          // storeMessage may already be triggered by 'message_create' event;
          // we just notify UI, avoid duplicate store.
          io.emit('message:new', {
            id: sent && sent.id && sent.id._serialized ? sent.id._serialized : null,
            chatId,
            fromMe: true,
            body: replyText,
            type: 'chat',
            ack: sent && sent.ack ? sent.ack : 0,
            ts: Date.now(),
            chatName: null,
            autoReply: true
          });
          io.emit('chat:update', { chatId });
        }
      } catch (_) {
        // socket emission failure should not break reply
      }
    } catch (e) {
      console.error('[AUTOREPLY] sendMessage failed:', e.message);
      // do not log as sent
    }
  } catch (e) {
    console.error('[AUTOREPLY] handleAutoReply error:', e.message);
  }
}

/**
 * Manual test matcher — used by a debug endpoint (optional).
 * Returns the reply that WOULD be sent, without sending.
 */
function previewReply(body) {
  const textLower = normalize(body);
  const db = getDb();
  const rules = db
    .prepare(
      `SELECT id, keyword, reply, match_type, enabled, priority
       FROM autoreply_rules WHERE enabled = 1
       ORDER BY priority ASC, id ASC`
    )
    .all();

  for (const rule of rules) {
    if (matchRule(rule, textLower)) {
      return { matched: true, ruleId: rule.id, keyword: rule.keyword, reply: rule.reply };
    }
  }

  const fallbackEnabled = getSetting('fallback_enabled', 'false') === 'true';
  const fallbackReply = getSetting('fallback_reply', '') || '';
  if (fallbackEnabled && fallbackReply.trim()) {
    return { matched: false, fallback: true, reply: fallbackReply };
  }

  return { matched: false, reply: null };
}

module.exports = {
  handleAutoReply,
  previewReply
};