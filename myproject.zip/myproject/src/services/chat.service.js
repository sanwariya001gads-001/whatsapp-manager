'use strict';

const { getDb } = require('../db');

/**
 * Chat Service
 * Wraps common DB reads/writes for chats.
 */

/**
 * List chats with optional search, ordered by recent activity.
 */
function listChats({ search = '', limit = 100 } = {}) {
  const db = getDb();
  const cap = Math.min(Math.max(parseInt(limit, 10) || 100, 1), 300);

  if (search && search.trim()) {
    const like = `%${search.trim().toLowerCase()}%`;
    return db
      .prepare(
        `SELECT id, name, number, last_message, last_ts, unread, is_group
         FROM chats
         WHERE LOWER(COALESCE(name,'')) LIKE ?
            OR COALESCE(number,'') LIKE ?
            OR LOWER(COALESCE(last_message,'')) LIKE ?
         ORDER BY COALESCE(last_ts, 0) DESC
         LIMIT ?`
      )
      .all(like, like, like, cap);
  }

  return db
    .prepare(
      `SELECT id, name, number, last_message, last_ts, unread, is_group
       FROM chats
       ORDER BY COALESCE(last_ts, 0) DESC
       LIMIT ?`
    )
    .all(cap);
}

/**
 * Get single chat meta.
 */
function getChat(chatId) {
  const db = getDb();
  return db
    .prepare('SELECT id, name, number, is_group FROM chats WHERE id = ?')
    .get(chatId);
}

/**
 * Ensure a chat row exists; create if not.
 */
function ensureChat(chatId, opts = {}) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM chats WHERE id = ?').get(chatId);
  if (existing) return existing.id;

  const number = chatId.includes('@c.us') ? chatId.replace('@c.us', '') : null;
  const name = opts.name || number || chatId;
  const isGroup = chatId.endsWith('@g.us') ? 1 : 0;

  db.prepare(
    `INSERT INTO chats (id, name, number, last_message, last_ts, unread, is_group, updated_at)
     VALUES (?, ?, ?, NULL, ?, 0, ?, ?)`
  ).run(chatId, name, number, Date.now(), isGroup, Date.now());

  return chatId;
}

/**
 * Mark chat as read.
 */
function markRead(chatId) {
  const db = getDb();
  return db.prepare('UPDATE chats SET unread = 0 WHERE id = ?').run(chatId);
}

/**
 * Increment unread counter for a chat.
 */
function incUnread(chatId) {
  const db = getDb();
  const res = db
    .prepare('UPDATE chats SET unread = unread + 1, updated_at = ? WHERE id = ?')
    .run(Date.now(), chatId);
  return res.changes > 0;
}

/**
 * Update last-message preview.
 */
function updateLastMessage(chatId, preview, ts) {
  const db = getDb();
  return db
    .prepare(
      `UPDATE chats SET last_message = ?, last_ts = ?, updated_at = ?
       WHERE id = ?`
    )
    .run(preview || '', ts || Date.now(), Date.now(), chatId);
}

/**
 * Total unread count across all chats.
 */
function totalUnread() {
  const db = getDb();
  const row = db.prepare('SELECT COALESCE(SUM(unread),0) AS n FROM chats').get();
  return row ? row.n : 0;
}

module.exports = {
  listChats,
  getChat,
  ensureChat,
  markRead,
  incUnread,
  updateLastMessage,
  totalUnread
};