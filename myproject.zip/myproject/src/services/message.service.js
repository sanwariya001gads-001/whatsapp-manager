'use strict';

const { getDb } = require('../db');

/**
 * Message Service
 * Wraps DB reads/writes for messages.
 */

/**
 * Get message history for a chat (oldest → newest), with cap.
 */
function getMessages(chatId, limit = 200) {
  const db = getDb();
  const cap = Math.min(Math.max(parseInt(limit, 10) || 200, 1), 500);
  return db
    .prepare(
      `SELECT id, chat_id, from_me, author, body, type, media_path, ack, ts
       FROM messages
       WHERE chat_id = ?
       ORDER BY ts ASC
       LIMIT ?`
    )
    .all(chatId, cap);
}

/**
 * Insert a message if not exists. Returns message id.
 */
function saveMessage(m) {
  const db = getDb();
  const exists = db.prepare('SELECT id FROM messages WHERE id = ?').get(m.id);
  if (exists) {
    // Update ack if changed
    if (typeof m.ack === 'number') {
      db.prepare('UPDATE messages SET ack = ? WHERE id = ?').run(m.ack, m.id);
    }
    return m.id;
  }

  db.prepare(
    `INSERT INTO messages
      (id, chat_id, from_me, author, body, type, media_path, ack, ts)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    m.id,
    m.chat_id,
    m.from_me ? 1 : 0,
    m.author || null,
    m.body || '',
    m.type || 'chat',
    m.media_path || null,
    typeof m.ack === 'number' ? m.ack : 0,
    m.ts || Date.now()
  );

  return m.id;
}

/**
 * Update delivery ack for a message.
 */
function updateAck(messageId, ack) {
  const db = getDb();
  return db.prepare('UPDATE messages SET ack = ? WHERE id = ?').run(ack, messageId);
}

/**
 * Preview text for chat list from a message.
 */
function makePreview(body, type) {
  const t = type || 'chat';
  if (t === 'chat') {
    return (body || '').slice(0, 120);
  }
  return `[${t}]`;
}

module.exports = {
  getMessages,
  saveMessage,
  updateAck,
  makePreview
};