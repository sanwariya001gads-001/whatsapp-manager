'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

let db = null;

/**
 * Initialize SQLite database + create tables + seed defaults.
 * Idempotent: safe to call multiple times.
 */
function initDb() {
  if (db) return db;

  const dataDir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  const dbPath = path.join(dataDir, 'app.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS chats (
      id            TEXT PRIMARY KEY,          -- WhatsApp chat id e.g. 9198xxxx@c.us
      name          TEXT,
      number        TEXT,
      last_message  TEXT,
      last_ts       INTEGER,                   -- unix ms
      unread        INTEGER NOT NULL DEFAULT 0,
      is_group      INTEGER NOT NULL DEFAULT 0,
      updated_at    INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id            TEXT PRIMARY KEY,          -- WhatsApp msg id or local uuid
      chat_id       TEXT NOT NULL,
      from_me       INTEGER NOT NULL DEFAULT 0,
      author        TEXT,
      body          TEXT,
      type          TEXT NOT NULL DEFAULT 'chat',
      media_path    TEXT,
      ack           INTEGER NOT NULL DEFAULT 0, -- 0 pending,1 sent,2 delivered,3 read
      ts            INTEGER NOT NULL,           -- unix ms
      FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_messages_chat_ts ON messages(chat_id, ts);

    CREATE TABLE IF NOT EXISTS autoreply_rules (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      keyword     TEXT NOT NULL,
      reply       TEXT NOT NULL,
      match_type  TEXT NOT NULL DEFAULT 'contains',  -- contains | exact | starts
      enabled     INTEGER NOT NULL DEFAULT 1,
      priority    INTEGER NOT NULL DEFAULT 0,
      created_at  INTEGER NOT NULL,
      updated_at  INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS autoreply_contacts (
      chat_id     TEXT PRIMARY KEY,
      disabled    INTEGER NOT NULL DEFAULT 1,
      updated_at  INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS autoreply_log (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_id     TEXT NOT NULL,
      keyword     TEXT,
      rule_id     INTEGER,
      reply_hash  TEXT,
      ts          INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_autoreply_log_chat_ts
      ON autoreply_log(chat_id, ts);

    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at    INTEGER NOT NULL
    );
  `);

  seedDefaults();
  return db;
}

/**
 * Seed global settings + default auto-reply rules (only first run).
 */
function seedDefaults() {
  const now = Date.now();

  const setIfMissing = (key, value) => {
    const row = db.prepare('SELECT key FROM settings WHERE key = ?').get(key);
    if (!row) {
      db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run(key, String(value));
    }
  };

  // Global settings
  setIfMissing('autoreply_enabled', process.env.AUTOREPLY_ENABLED || 'true');
  setIfMissing(
    'autoreply_cooldown_seconds',
    process.env.AUTOREPLY_COOLDOWN_SECONDS || '60'
  );
  setIfMissing(
    'autoreply_duplicate_window_seconds',
    process.env.AUTOREPLY_DUPLICATE_WINDOW_SECONDS || '30'
  );
  setIfMissing('fallback_reply', ''); // empty = disabled
  setIfMissing('fallback_enabled', 'false');

  // Default keyword rules (only if table empty)
  const count = db.prepare('SELECT COUNT(*) AS c FROM autoreply_rules').get().c;
  if (count === 0) {
    const insertRule = db.prepare(
      `INSERT INTO autoreply_rules
        (keyword, reply, match_type, enabled, priority, created_at, updated_at)
       VALUES (?, ?, ?, 1, ?, ?, ?)`
    );

    const defaultRules = [
      {
        keyword: 'hi',
        match_type: 'exact',
        priority: 1,
        reply:
          'Welcome to Lion Photography! 📸\nType:\n1 - Packages\n2 - Wedding Booking\n3 - Contact Info'
      },
      {
        keyword: 'hello',
        match_type: 'exact',
        priority: 1,
        reply:
          'Welcome to Lion Photography! 📸\nType:\n1 - Packages\n2 - Wedding Booking\n3 - Contact Info'
      },
      {
        keyword: 'hey',
        match_type: 'exact',
        priority: 1,
        reply:
          'Welcome to Lion Photography! 📸\nType:\n1 - Packages\n2 - Wedding Booking\n3 - Contact Info'
      },
      {
        keyword: '1',
        match_type: 'exact',
        priority: 2,
        reply:
          '📦 *Photography Packages*\n- Basic: ₹4,999\n- Standard: ₹9,999\n- Premium: ₹19,999\nReply 2 for wedding details.'
      },
      {
        keyword: '2',
        match_type: 'exact',
        priority: 2,
        reply:
          '💍 *Wedding Booking*\nDate availability, advance, and full-day coverage.\nPlease share your event date & city.\nReply 3 for contact.'
      },
      {
        keyword: '3',
        match_type: 'exact',
        priority: 2,
        reply:
          '📞 *Contact Lion Photography*\nPhone: +91-XXXXXXXXXX\nEmail: hello@lionphotography.example\nInstagram: @lionphotography'
      }
    ];

    const tx = db.transaction((rules) => {
      for (const r of rules) {
        insertRule.run(r.keyword, r.reply, r.match_type, r.priority, now, now);
      }
    });
    tx(defaultRules);
  }
}

/** Get raw db instance (must call initDb first). */
function getDb() {
  if (!db) throw new Error('DB not initialized. Call initDb() first.');
  return db;
}

// ---------- Settings helpers ----------
function getSetting(key, fallback = null) {
  const row = getDb().prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : fallback;
}

function setSetting(key, value) {
  getDb()
    .prepare(
      `INSERT INTO settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    )
    .run(key, String(value));
}

function getAllSettings() {
  const rows = getDb().prepare('SELECT key, value FROM settings').all();
  const out = {};
  for (const r of rows) out[r.key] = r.value;
  return out;
}

module.exports = {
  initDb,
  getDb,
  getSetting,
  setSetting,
  getAllSettings
};