'use strict';

const express = require('express');
const QRCode = require('qrcode');

const wa = require('../whatsapp');

const router = express.Router();

/**
 * GET /api/whatsapp/status
 */
router.get('/status', (req, res) => {
  res.json({ ok: true, state: wa.getPublicState() });
});

/**
 * GET /api/whatsapp/qr
 * Returns QR as data URL if waiting for scan.
 */
router.get('/qr', async (req, res, next) => {
  try {
    const state = wa.getState();
    if (state.status !== 'waiting_qr' || !state.qrDataUrl) {
      return res.json({
        ok: true,
        available: false,
        status: state.status,
        message:
          state.status === 'connected'
            ? 'Already connected'
            : 'No QR available right now'
      });
    }
    res.json({
      ok: true,
      available: true,
      dataUrl: state.qrDataUrl,
      ts: state.updatedAt
    });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/whatsapp/refresh
 * Force a new QR by destroying + reinitializing.
 */
router.post('/refresh', async (req, res, next) => {
  try {
    await wa.refreshQr();
    res.json({ ok: true, message: 'QR refresh triggered' });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/whatsapp/reconnect
 */
router.post('/reconnect', async (req, res, next) => {
  try {
    await wa.reconnect();
    res.json({ ok: true, message: 'Reconnect triggered' });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/whatsapp/logout
 * Destroys client + deletes session folder.
 */
router.post('/logout', async (req, res, next) => {
  try {
    await wa.logout();
    res.json({ ok: true, message: 'Logged out and session cleared' });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/whatsapp/sync
 * Re-sync recent chats from WhatsApp.
 */
router.post('/sync', async (req, res, next) => {
  try {
    await wa.syncRecentChats(50);
    res.json({ ok: true, message: 'Chat sync triggered' });
  } catch (e) {
    next(e);
  }
});

module.exports = router;