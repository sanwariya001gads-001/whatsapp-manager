'use strict';

const express = require('express');
const bcrypt = require('bcryptjs');

const { getDb } = require('../db');
const { loginLimiter } = require('../middleware/rateLimit');
const { sanitizeString } = require('../middleware/validate');

const router = express.Router();

const AUTH_ENABLED = String(process.env.AUTH_ENABLED || 'false').toLowerCase() === 'true';

/**
 * POST /api/auth/login
 * Body: { username, password }
 */
router.post('/login', loginLimiter, async (req, res, next) => {
  try {
    if (!AUTH_ENABLED) {
      // Auth disabled: create a session anyway so subsequent calls work
      req.session.userId = 0;
      return res.json({ ok: true, authEnabled: false });
    }

    const username = sanitizeString(req.body.username || '', 64).trim();
    const password = typeof req.body.password === 'string' ? req.body.password : '';

    if (!username || !password) {
      return res.status(400).json({ ok: false, error: 'Username and password required' });
    }

    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);

    if (!user) {
      // Time-safe fail
      await bcrypt.compare(password, '$2a$10$invalidhashinvalidhashinvalidhashinvalidha');
      return res.status(401).json({ ok: false, error: 'Invalid credentials' });
    }

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ ok: false, error: 'Invalid credentials' });
    }

    req.session.userId = user.id;
    return res.json({ ok: true, authEnabled: true, username: user.username });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/auth/logout
 */
router.post('/logout', (req, res) => {
  if (req.session) {
    req.session.destroy(() => {});
  }
  res.clearCookie('wacm.sid');
  res.json({ ok: true });
});

/**
 * GET /api/auth/me
 */
router.get('/me', (req, res) => {
  const enabled = AUTH_ENABLED;
  if (!enabled) {
    return res.json({ ok: true, authEnabled: false, authenticated: true });
  }
  if (req.session && req.session.userId) {
    return res.json({ ok: true, authEnabled: true, authenticated: true });
  }
  return res.status(401).json({ ok: false, authenticated: false });
});

module.exports = router;