'use strict';

const express = require('express');
const { getDb, getSetting, setSetting, getAllSettings } = require('../db');
const { validateBody } = require('../middleware/validate');

const router = express.Router();

/**
 * GET /api/autoreply/settings
 */
router.get('/settings', (req, res, next) => {
  try {
    const all = getAllSettings();
    res.json({
      ok: true,
      settings: {
        enabled: all.autoreply_enabled === 'true',
        cooldownSeconds: parseInt(all.autoreply_cooldown_seconds || '60', 10),
        duplicateWindowSeconds: parseInt(
          all.autoreply_duplicate_window_seconds || '30',
          10
        ),
        fallbackEnabled: all.fallback_enabled === 'true',
        fallbackReply: all.fallback_reply || ''
      }
    });
  } catch (e) {
    next(e);
  }
});

/**
 * PATCH /api/autoreply/settings
 * Body (all optional): { enabled, cooldownSeconds, duplicateWindowSeconds, fallbackEnabled, fallbackReply }
 */
router.patch(
  '/settings',
  validateBody({
    enabled: { type: 'boolean' },
    cooldownSeconds: { type: 'number' },
    duplicateWindowSeconds: { type: 'number' },
    fallbackEnabled: { type: 'boolean' },
    fallbackReply: { type: 'string', maxLen: 4096, sanitize: true }
  }),
  (req, res, next) => {
    try {
      const b = req.body || {};
      if (typeof b.enabled === 'boolean') setSetting('autoreply_enabled', b.enabled ? 'true' : 'false');
      if (typeof b.cooldownSeconds === 'number')
        setSetting('autoreply_cooldown_seconds', Math.max(0, Math.min(86400, Math.floor(b.cooldownSeconds))));
      if (typeof b.duplicateWindowSeconds === 'number')
        setSetting(
          'autoreply_duplicate_window_seconds',
          Math.max(0, Math.min(3600, Math.floor(b.duplicateWindowSeconds)))
        );
      if (typeof b.fallbackEnabled === 'boolean')
        setSetting('fallback_enabled', b.fallbackEnabled ? 'true' : 'false');
      if (typeof b.fallbackReply === 'string') setSetting('fallback_reply', b.fallbackReply);

      res.json({ ok: true });
    } catch (e) {
      next(e);
    }
  }
);

/**
 * GET /api/autoreply/rules
 */
router.get('/rules', (req, res, next) => {
  try {
    const db = getDb();
    const rows = db
      .prepare(
        `SELECT id, keyword, reply, match_type, enabled, priority, created_at, updated_at
         FROM autoreply_rules
         ORDER BY priority ASC, id ASC`
      )
      .all();
    res.json({ ok: true, rules: rows });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/autoreply/rules
 * Body: { keyword, reply, match_type, enabled, priority }
 */
router.post(
  '/rules',
  validateBody({
    keyword: { required: true, type: 'string', maxLen: 128, sanitize: true },
    reply: { required: true, type: 'string', maxLen: 4096, sanitize: true },
    match_type: { type: 'string', enum: ['contains', 'exact', 'starts'] },
    enabled: { type: 'boolean' },
    priority: { type: 'number' }
  }),
  (req, res, next) => {
    try {
      const db = getDb();
      const b = req.body;
      const now = Date.now();
      const info = db
        .prepare(
          `INSERT INTO autoreply_rules
            (keyword, reply, match_type, enabled, priority, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          b.keyword.trim(),
          b.reply,
          b.match_type || 'contains',
          b.enabled === false ? 0 : 1,
          Number.isFinite(b.priority) ? b.priority : 0,
          now,
          now
        );
      res.json({ ok: true, id: info.lastInsertRowid });
    } catch (e) {
      next(e);
    }
  }
);

/**
 * PUT /api/autoreply/rules/:id
 */
router.put(
  '/rules/:id',
  validateBody({
    keyword: { type: 'string', maxLen: 128, sanitize: true },
    reply: { type: 'string', maxLen: 4096, sanitize: true },
    match_type: { type: 'string', enum: ['contains', 'exact', 'starts'] },
    enabled: { type: 'boolean' },
    priority: { type: 'number' }
  }),
  (req, res, next) => {
    try {
      const db = getDb();
      const id = parseInt(req.params.id, 10);
      if (!id) return res.status(400).json({ ok: false, error: 'Invalid id' });

      const existing = db.prepare('SELECT * FROM autoreply_rules WHERE id = ?').get(id);
      if (!existing) return res.status(404).json({ ok: false, error: 'Rule not found' });

      const b = req.body || {};
      const merged = {
        keyword: b.keyword !== undefined ? b.keyword.trim() : existing.keyword,
        reply: b.reply !== undefined ? b.reply : existing.reply,
        match_type: b.match_type !== undefined ? b.match_type : existing.match_type,
        enabled: b.enabled !== undefined ? (b.enabled ? 1 : 0) : existing.enabled,
        priority: b.priority !== undefined ? b.priority : existing.priority
      };

      db.prepare(
        `UPDATE autoreply_rules
         SET keyword = ?, reply = ?, match_type = ?, enabled = ?, priority = ?, updated_at = ?
         WHERE id = ?`
      ).run(
        merged.keyword,
        merged.reply,
        merged.match_type,
        merged.enabled,
        merged.priority,
        Date.now(),
        id
      );

      res.json({ ok: true });
    } catch (e) {
      next(e);
    }
  }
);

/**
 * DELETE /api/autoreply/rules/:id
 */
router.delete('/rules/:id', (req, res, next) => {
  try {
    const db = getDb();
    const id = parseInt(req.params.id, 10);
    if (!id) return res.status(400).json({ ok: false, error: 'Invalid id' });
    const info = db.prepare('DELETE FROM autoreply_rules WHERE id = ?').run(id);
    if (info.changes === 0) return res.status(404).json({ ok: false, error: 'Rule not found' });
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

/**
 * GET /api/autoreply/contacts
 * List contacts with auto-reply disabled.
 */
router.get('/contacts', (req, res, next) => {
  try {
    const db = getDb();
    const rows = db
      .prepare(
        `SELECT chat_id, disabled, updated_at
         FROM autoreply_contacts
         WHERE disabled = 1
         ORDER BY updated_at DESC`
      )
      .all();
    res.json({ ok: true, contacts: rows });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/autoreply/contacts/:chatId/disable
 * POST /api/autoreply/contacts/:chatId/enable
 */
router.post('/contacts/:chatId/disable', (req, res, next) => {
  try {
    const db = getDb();
    const chatId = req.params.chatId;
    if (!/^[\d\-]+@(c\.us|g\.us)$/.test(chatId)) {
      return res.status(400).json({ ok: false, error: 'Invalid chatId' });
    }
    db.prepare(
      `INSERT INTO autoreply_contacts (chat_id, disabled, updated_at) VALUES (?, 1, ?)
       ON CONFLICT(chat_id) DO UPDATE SET disabled = 1, updated_at = excluded.updated_at`
    ).run(chatId, Date.now());
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

router.post('/contacts/:chatId/enable', (req, res, next) => {
  try {
    const db = getDb();
    const chatId = req.params.chatId;
    if (!/^[\d\-]+@(c\.us|g\.us)$/.test(chatId)) {
      return res.status(400).json({ ok: false, error: 'Invalid chatId' });
    }
    db.prepare('DELETE FROM autoreply_contacts WHERE chat_id = ?').run(chatId);
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

module.exports = router;