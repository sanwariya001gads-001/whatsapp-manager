'use strict';

const express = require('express');
const { getDb } = require('../db');
const { validateBody } = require('../middleware/validate');

const router = express.Router();

/**
 * GET /api/chats?search=&limit=
 * Returns chat list ordered by last_ts desc.
 */
router.get('/', (req, res, next) => {
  try {
    const db = getDb();
    const search =
      typeof req.query.search === 'string' ? req.query.search.trim() : '';
    const limit = Math.min(parseInt(req.query.limit || '100', 10) || 100, 300);

    let rows;
    if (search) {
      const like = `%${search.toLowerCase()}%`;
      rows = db
        .prepare(
          `SELECT id, name, number, last_message, last_ts, unread, is_group
           FROM chats
           WHERE LOWER(COALESCE(name,'')) LIKE ?
              OR COALESCE(number,'') LIKE ?
              OR LOWER(COALESCE(last_message,'')) LIKE ?
           ORDER BY COALESCE(last_ts, 0) DESC
           LIMIT ?`
        )
        .all(like, like, like, limit);
    } else {
      rows = db
        .prepare(
          `SELECT id, name, number, last_message, last_ts, unread, is_group
           FROM chats
           ORDER BY COALESCE(last_ts, 0) DESC
           LIMIT ?`
        )
        .all(limit);
    }

    res.json({ ok: true, chats: rows });
  } catch (e) {
    next(e);
  }
});

/**
 * GET /api/chats/:id/messages?limit=200
 */
router.get('/:id/messages', (req, res, next) => {
  try {
    const db = getDb();
    const chatId = req.params.id;
    if (!/^[\d\-]+@(c\.us|g\.us)$/.test(chatId)) {
      return res.status(400).json({ ok: false, error: 'Invalid chat id' });
    }
    const limit = Math.min(parseInt(req.query.limit || '200', 10) || 200, 500);

    const chat = db
      .prepare('SELECT id, name, number, is_group FROM chats WHERE id = ?')
      .get(chatId);

    if (!chat) {
      return res.status(404).json({ ok: false, error: 'Chat not found' });
    }

    const messages = db
      .prepare(
        `SELECT id, chat_id, from_me, author, body, type, media_path, ack, ts
         FROM messages
         WHERE chat_id = ?
         ORDER BY ts ASC
         LIMIT ?`
      )
      .all(chatId, limit);

    // Mark chat unread = 0 (we opened it)
    db.prepare('UPDATE chats SET unread = 0 WHERE id = ?').run(chatId);

    res.json({ ok: true, chat, messages });
  } catch (e) {
    next(e);
  }
});

/**
 * POST /api/chats/:id/read
 * Mark a chat as read.
 */
router.post('/:id/read', (req, res, next) => {
  try {
    const db = getDb();
    const chatId = req.params.id;
    if (!/^[\d\-]+@(c\.us|g\.us)$/.test(chatId)) {
      return res.status(400).json({ ok: false, error: 'Invalid chat id' });
    }
    db.prepare('UPDATE chats SET unread = 0 WHERE id = ?').run(chatId);
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

module.exports = router;