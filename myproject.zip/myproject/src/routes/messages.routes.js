'use strict';

const express = require('express');
const wa = require('../whatsapp');
const { sendLimiter } = require('../middleware/rateLimit');
const { validateBody } = require('../middleware/validate');

const router = express.Router();

/**
 * POST /api/messages/send
 * Body: { chatId: "9198xxxx@c.us", text: "hello" }
 */
router.post(
  '/send',
  sendLimiter,
  validateBody({
    chatId: { required: true, type: 'string', chatId: true },
    text: { required: true, type: 'string', maxLen: 4096, sanitize: true }
  }),
  async (req, res, next) => {
    try {
      const { chatId } = req.body;
      const text = (req.body.text || '').trim();

      if (!text) {
        return res.status(400).json({ ok: false, error: 'Empty message' });
      }

      const result = await wa.sendText(chatId, text);
      res.json({
        ok: true,
        message: {
          id: result.id,
          chatId: result.chatId,
          ack: result.ack,
          ts: result.ts
        }
      });
    } catch (e) {
      const status = e.status || 500;
      const message = e.expose ? e.message : 'Failed to send message';
      res.status(status).json({ ok: false, error: message });
    }
  }
);

module.exports = router;