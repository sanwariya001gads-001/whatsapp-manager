'use strict';

/**
 * Basic input sanitization (trim + strip control chars).
 * Note: React/HTML escaping must be done on the frontend for XSS.
 */
function sanitizeString(input, maxLen = 4096) {
  if (typeof input !== 'string') return '';
  // Remove null bytes + most control chars (keep \n, \r, \t)
  let s = input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
  if (s.length > maxLen) s = s.slice(0, maxLen);
  return s;
}

/**
 * Validate WhatsApp chatId (either user@c.us or group@g.us).
 */
function isValidChatId(chatId) {
  return (
    typeof chatId === 'string' &&
    /^[\d\-]+@(c\.us|g\.us)$/.test(chatId) &&
    chatId.length < 128
  );
}

/**
 * Express middleware factory: validates body fields.
 */
function validateBody(rules) {
  return (req, res, next) => {
    const errors = [];
    const body = req.body || {};

    for (const [field, rule] of Object.entries(rules)) {
      const val = body[field];

      if (rule.required && (val === undefined || val === null || val === '')) {
        errors.push(`${field} is required`);
        continue;
      }
      if (val === undefined || val === null) continue;

      if (rule.type === 'string' && typeof val !== 'string') {
        errors.push(`${field} must be a string`);
        continue;
      }
      if (rule.type === 'number' && typeof val !== 'number') {
        errors.push(`${field} must be a number`);
        continue;
      }
      if (rule.type === 'boolean' && typeof val !== 'boolean') {
        errors.push(`${field} must be a boolean`);
        continue;
      }
      if (rule.type === 'string' && rule.maxLen && val.length > rule.maxLen) {
        errors.push(`${field} exceeds max length ${rule.maxLen}`);
      }
      if (rule.type === 'string' && rule.sanitize) {
        body[field] = sanitizeString(val, rule.maxLen || 4096);
      }
      if (rule.enum && rule.enum.length && !rule.enum.includes(val)) {
        errors.push(`${field} must be one of: ${rule.enum.join(', ')}`);
      }
      if (rule.chatId && !isValidChatId(val)) {
        errors.push(`${field} is not a valid WhatsApp chatId`);
      }
    }

    if (errors.length) {
      return res.status(400).json({ ok: false, error: errors.join('; ') });
    }
    next();
  };
}

module.exports = {
  sanitizeString,
  isValidChatId,
  validateBody
};