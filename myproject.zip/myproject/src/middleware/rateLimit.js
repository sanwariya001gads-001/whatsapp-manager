'use strict';

const rateLimit = require('express-rate-limit');

const globalLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 300, // 300 req/min per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many requests, slow down' }
});

const sendLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30, // 30 sends/min
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many messages sent, slow down' }
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10, // 10 login attempts / 15 min
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many login attempts' }
});

module.exports = { globalLimiter, sendLimiter, loginLimiter };