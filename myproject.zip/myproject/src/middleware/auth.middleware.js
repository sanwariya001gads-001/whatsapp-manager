'use strict';

/**
 * Require authenticated session (only used when AUTH_ENABLED=true).
 */
function requireAuth(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  }
  return res.status(401).json({ ok: false, error: 'Authentication required' });
}

module.exports = { requireAuth };