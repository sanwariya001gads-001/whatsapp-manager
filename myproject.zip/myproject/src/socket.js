'use strict';

const { Server } = require('socket.io');

let io = null;

function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: (origin, cb) => {
        if (!origin) return cb(null, true);
        const ok =
          origin.startsWith('http://127.0.0.1') ||
          origin.startsWith('http://localhost');
        cb(ok ? null : new Error('Not allowed'), ok);
      },
      credentials: true
    },
    maxHttpBufferSize: 1e6
  });

  io.on('connection', (socket) => {
    console.log('[SOCKET] client connected:', socket.id);

    // Send current WA state on connect
    try {
      const { getPublicState } = require('./whatsapp');
      socket.emit('wa:state', getPublicState());
    } catch (_) {}

    socket.on('disconnect', (reason) => {
      console.log('[SOCKET] client disconnected:', socket.id, reason);
    });
  });

  return io;
}

function getIo() {
  return io;
}

module.exports = { initSocket, getIo };